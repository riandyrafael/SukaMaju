package com.example.myapplication;

import android.net.Uri;

import com.example.myapplication.PictureItem;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.PUT;

public interface ApiInterface {
    @GET("picture_item")
    Call<GetPictureItem> getPictureItem();
    @FormUrlEncoded
    @POST("picture")
    Call<PostPictureItem> postPictureItem(@Field("nama") String nama,
                                          @Field("photo")Uri photo);

}
