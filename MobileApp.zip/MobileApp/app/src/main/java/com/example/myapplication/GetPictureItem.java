package com.example.myapplication;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetPictureItem {
    @SerializedName("id")
    int id;
    @SerializedName("nama")
    String nama;
    @SerializedName("photo")
    String photo;
    @SerializedName("status")
    String status;
    @SerializedName("created_at")
    String created_at;
    @SerializedName("updated_at")
    String updated_at;
    @SerializedName("result")
    List<PictureItem> listPictureItem;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<PictureItem> getListPictureItem() {
        return listPictureItem;
    }

    public void setListPictureItem(List<PictureItem> listPictureItem) {
        this.listPictureItem = listPictureItem;
    }
}
