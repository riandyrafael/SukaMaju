package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class ViewHistory extends AppCompatActivity {

    Button btIns;
    ApiInterface mApiInterface;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    public static ViewHistory ma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_history);

        btIns = (Button) findViewById(R.id.btIns);
        btIns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ViewHistory.this, MainActivity.class));
            }
        });
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        ma=this;
        refresh();
    }

    public void refresh() {
        Call<GetPictureItem> pictureItemCall = mApiInterface.getPictureItem();
        pictureItemCall.enqueue(new Callback<GetPictureItem>() {
            @Override
            public void onResponse(Call<GetPictureItem> pictureItemCal1, Response<GetPictureItem> response) {

                if (!response.isSuccessful()) {

                }

                List<PictureItem> PictureItemList = response.body().getListPictureItem();
                Log.d("Retrofit Get","Jumlah Data Image" +
                        String.valueOf(PictureItemList.size()));

                LinearLayoutManager manager = new LinearLayoutManager(ma);
                mRecyclerView.setLayoutManager(manager);
                mRecyclerView.setHasFixedSize(true);
                mAdapter = new PictureItemAdapter(PictureItemList);
                mRecyclerView.setAdapter(mAdapter);

            }

            @Override
            public void onFailure(Call<GetPictureItem> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }


//////////////////
        });
    }
}
