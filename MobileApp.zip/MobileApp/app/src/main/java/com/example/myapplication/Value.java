package com.example.myapplication;

import java.util.List;

public class Value {
    List<PictureItem> result;

    public List<PictureItem> getResult() {
        return result;
    }
}
