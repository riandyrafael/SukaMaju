package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.IOException;
import java.util.concurrent.FutureTask;

public class MainActivity extends AppCompatActivity {
    private Camera mCamera = null;
    private CameraView mCameraView = null;

    public static final int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            mCamera = Camera.open();
        }catch (Exception e)
        {
            Log.e("ERROR","Camera Error on Surface View"+ e.getMessage());
        }

        if(mCamera != null){
            Bitmap bm = null;

            mCameraView = new CameraView(this, mCamera);

            ImageView camera_view2 = (ImageView) findViewById(R.id.imageView);
            final FrameLayout camera_view = (FrameLayout) findViewById(R.id.frameLayout);
            camera_view.addView(mCameraView);
            camera_view.setDrawingCacheEnabled(true);
            camera_view.buildDrawingCache();
            bm = camera_view.getDrawingCache();
            camera_view2.setImageBitmap(bm);

            Button btnStop = (Button) findViewById(R.id.button);
            btnStop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mCamera.stopPreview();
                    mCamera.release();
                }
            });

            Button btnPick = (Button) findViewById(R.id.button2);
            btnPick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    pickImage();
                }
            });
        }




    }

    public void pickImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == PICK_IMAGE) {
            Uri uri = data.getData();

            try{
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);

                ImageView imageView = findViewById(R.id.imageView);
                imageView.setImageBitmap(bitmap);


            }catch (IOException e){

            }
        }
    }
}
