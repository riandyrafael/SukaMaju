package com.example.myapplication;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import com.example.myapplication.ViewHistory;
import com.example.myapplication.PictureItem;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.R;

public class PictureItemAdapter extends RecyclerView.Adapter<PictureItemAdapter.MyViewHolder> {
    List<PictureItem> mPictureItem;

    public PictureItemAdapter(List<PictureItem> PictureItem) {
        this.mPictureItem = PictureItem;
    }

    @Override
    public MyViewHolder onCreateViewHolder (ViewGroup parent,int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.pictureitem_list, parent, false);
        MyViewHolder mViewHolder = new MyViewHolder(mView);

        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.mTextViewId.setText("Id = " + mPictureItem.get(position).getId());
        holder.mTextViewNama.setText("Nama = " + mPictureItem.get(position).getNama());
        holder.mTextViewStatus.setText("Status = " + mPictureItem.get(position).getStatus());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(view.getContext(), ViewHistory.class);
                mIntent.putExtra("Id", mPictureItem.get(position).getId());
                mIntent.putExtra("Nama", mPictureItem.get(position).getNama());
                mIntent.putExtra("Status", mPictureItem.get(position).getStatus());
                view.getContext().startActivity(mIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mPictureItem.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextViewId, mTextViewNama, mTextViewStatus;

        public MyViewHolder(View itemView) {
            super(itemView);
            mTextViewId = (TextView) itemView.findViewById(R.id.tvId);
            mTextViewNama = (TextView) itemView.findViewById(R.id.tvNama);
            mTextViewStatus= (TextView) itemView.findViewById(R.id.tvStatus);
        }
    }
}
