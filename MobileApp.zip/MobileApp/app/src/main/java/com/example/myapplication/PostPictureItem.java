package com.example.myapplication;

import android.net.Uri;

import com.google.gson.annotations.SerializedName;

public class PostPictureItem {
    @SerializedName("nama")
    String nama;
    @SerializedName("photo")
    Uri photo;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public Uri getPhoto() {
        return photo;
    }

    public void setPhoto(Uri photo) {
        this.photo = photo;
    }
}
