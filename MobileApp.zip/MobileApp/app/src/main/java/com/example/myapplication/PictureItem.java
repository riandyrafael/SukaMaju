package com.example.myapplication;

import android.net.Uri;

public class PictureItem {
    int id;
    Uri uri;
    String nama;
    int status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Uri getUri() { return uri; }

    public void setUri(Uri uri) { this.uri = uri; }

    public String getNama() { return nama; }

    public void setNama(String nama) { this.nama = nama; }

    public int getStatus() { return status; }

    public void setStatus(int status) { this.status = status; }

    public PictureItem(int id, Uri uri, String nama, int status) {
        this.id = id;
        this.uri = uri;
        this.nama = nama;
        this.status = status;
    }
}
